import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.JComponent;

import libs.*;

public class CpuAdapter extends JComponent implements Adapter {

  private CpuUtilizationSensor cSensor;
  private double value;

  public CpuAdapter(CpuUtilizationSensor sensor) {
    cSensor = sensor;
    setPreferredSize(new Dimension(300, 300));
  }

  @Override
  public double readValue() {
    value = cSensor.readValue();
    return value;
  }

  @Override
  public String getReport() {
    return cSensor.getReport();
  }

  @Override
  public String getAlertName() {
    return cSensor.getAlertName();
     
  }

  @Override
  protected void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.setColor(findRectColor());
    int size = sizeWidthRect();
    String printString = getReport() + "-->" + value;
    g.drawRect(20, 20, size, 50); //100
    g.fillRect(20, 20, size, 50);
    g.setColor(Color.BLACK);
    g.drawString(printString, 100, 150);

  }

  @Override
  public Color findRectColor() {
    if (value < 75.0) {
      return Color.GREEN;
    } else if (value >= 75.0 && value <= 90.0) {
      return Color.YELLOW;
    } 

    return Color.RED; 
  }

  @Override
  public int sizeWidthRect() {
    return (int) value;
  }
  
}
