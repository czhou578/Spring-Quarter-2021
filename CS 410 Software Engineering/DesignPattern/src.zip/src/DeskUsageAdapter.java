import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import javax.swing.*;
import libs.DeskUsageSensor;

public class DeskUsageAdapter extends JComponent implements Adapter  {

  private DeskUsageSensor deskSensor;
  private double value;


  public DeskUsageAdapter(DeskUsageSensor sensor) {
    deskSensor = sensor;
    setPreferredSize(new Dimension(300, 300));
  }

  @Override
  public double readValue() {
    value = deskSensor.readValue();
    return value;
  }

  @Override
  public String getReport() {
    return deskSensor.getReport();
  }

  @Override
  public String getAlertName() {
    return deskSensor.getAlertName();
  }

  @Override
  protected void paintComponent(Graphics g) { //change third parameter
     super.paintComponent(g);
     g.setColor(findRectColor());
     int size = sizeWidthRect();
     String printString = getReport() + "--> " + value;
     g.drawRect(20, 20, size / 10, 50);
     g.fillRect(20, 20, size / 10, 50);
     g.setColor(Color.BLACK);
     g.drawString(printString, 100, 150);
  }

  @Override
  public Color findRectColor() {
    if (value < 700.0) {
      return Color.GREEN;
    } else if (value >= 700.0 && value <= 900.0) {
      return Color.YELLOW;
    } 
    return Color.RED;

  }

  @Override
  public int sizeWidthRect() {
    return (int) value;    
  }

}
