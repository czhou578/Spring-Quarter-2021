import java.awt.Color;

public interface Adapter {
  
  public double readValue();
  public java.lang.String getReport();
  public java.lang.String getAlertName();
  public Color findRectColor();
  public int sizeWidthRect();
}
