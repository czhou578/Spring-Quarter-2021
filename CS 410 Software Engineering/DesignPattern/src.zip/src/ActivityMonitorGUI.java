import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.TitledBorder;
import libs.CpuUtilizationSensor;
import libs.DeskUsageSensor;
import libs.MemoryUsageSensor;

public class ActivityMonitorGUI extends JFrame {
    
    public ActivityMonitorGUI() {
        CpuUtilizationSensor cSensor = new CpuUtilizationSensor();
        CpuAdapter adapter = new CpuAdapter(cSensor);

        adapter.readValue();       
        
        DeskUsageSensor dSensor = new DeskUsageSensor();
        DeskUsageAdapter adapter2 = new DeskUsageAdapter(dSensor);
        
        adapter2.readValue();
        
        MemoryUsageSensor memSensor = new MemoryUsageSensor();
        MemoryUsageAdapter adapter3 = new MemoryUsageAdapter(memSensor);
        
        adapter3.readValue();
        
        setTitle("Activity Monitor Tracker");
        setLayout(new GridLayout(3,1));
        
        JPanel cpuUsagePanel = new JPanel();
        cpuUsagePanel.setBorder(new TitledBorder("CPU Utilization Alert"));
        cpuUsagePanel.add(adapter);
        add(cpuUsagePanel);

        JPanel memoryUsagePnl = new JPanel();
        memoryUsagePnl.setBorder(new TitledBorder("Memory Usage Alert"));
        memoryUsagePnl.add(adapter3);
        add(memoryUsagePnl);

        JPanel deskUsageJPanel = new JPanel();
        deskUsageJPanel.setBorder(new TitledBorder("Desk Usage Alert"));
        deskUsageJPanel.add(adapter2);
        add(deskUsageJPanel);

        setPreferredSize(new Dimension(600,600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
        pack();
    }

    public static void main(String[] args) {

        ActivityMonitorGUI gui = new ActivityMonitorGUI();
    }

}
